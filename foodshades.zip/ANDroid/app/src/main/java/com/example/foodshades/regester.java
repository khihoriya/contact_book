package com.example.foodshades;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class regester extends AppCompatActivity {
        Button btn;
        Button btn1;
        Spinner spinner;
        String[] cities={"Surat","Mumbai","Delhi","Kolkata","Ahemdabad",};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regester);
        btn1=findViewById(R.id.regester);
        btn1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent i =new Intent(regester.this,thirdpage.class);
        startActivity(i);
    }
});


    spinner = findViewById(R.id.spinner1);
        ArrayAdapter<String> spinneradapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,cities);
        spinner.setAdapter(spinneradapter1);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(), cities[i+1], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        btn=findViewById(R.id.login);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(regester.this,MainActivity.class);
                startActivity(i);
            }
        });

    }

}