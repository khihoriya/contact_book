package com.example.foodshades;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class thirdpage extends AppCompatActivity {

//    ArrayList<String> arrnames=new ArrayList<>();
    String[] arrnames ={"Hot Coffee","Caffe Misto","Cappuccino","Espresso","Pumpkin Spice"};
    String[] arrice = {"Buttered Pecan","Mint Chocolate Chip","Neapolitan","Moose Tracks","Vanilla",};
    String[] arrfood={"Apple Pie","cheesesteaks","lobster rolls","barbecue","Country Fried Steak",};
    String[] arrshake={"Vanilla","Cool mint.","Strawberry marshallow","Neapolitan","Pina colada",};

    Spinner spinner;
    Spinner spinner1;
    Spinner spinner2;
    Spinner spinner3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thirdpage);

       spinner = findViewById(R.id.spinner);
       spinner1 = findViewById(R.id.spinner1);
        spinner2 = findViewById(R.id.spinner2);
        spinner3 = findViewById(R.id.spinner3);





        ArrayAdapter<String> spinneradapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,arrnames);
        spinner.setAdapter(spinneradapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                Toast.makeText(getApplicationContext(), arrnames[position], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        ArrayAdapter<String> spinneradapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,arrice);
        spinner1.setAdapter(spinneradapter1);




        ArrayAdapter<String> spinneradapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,arrfood);
        spinner2.setAdapter(spinneradapter2);



        ArrayAdapter<String> spinneradapter3 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,arrshake);
        spinner3.setAdapter(spinneradapter3);
    }
}